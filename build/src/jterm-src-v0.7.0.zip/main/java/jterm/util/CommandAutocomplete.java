package jterm.util;

import jterm.JTerm;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Set;

/**
 * Class that autocompletes filenames.
 */
public class CommandAutocomplete {

    private static String[] commands;
    private static String command = "";

    private static boolean available = true;

    public static void init(String[] commands) {
        if (!available)
            return;

        available = false;

        CommandAutocomplete.commands = commands;

        commandAutocomplete();

        available = true;
    }

    public static void commandAutocomplete() {
        Set<String> commandList = JTerm.getCommands();
        Set<String> possibilities;

        for (String compareCommand : commandList) {
            for (String command : CommandAutocomplete.commands) {
                if (compareCommand.contains(command)) {
                    JTerm.out.println(command);
                    // JTerm.out.println(compareCommand);
                }
            }
        }
    }

    private static void autocomplete() {
        // String command = commands.getFirst();

        // Util.clearLine(command, true);

        // JTerm.out.printWithPrompt(command);
    }
}
